from flask import Flask, render_template, request, redirect, url_for, session, flash, send_file
import mysql.connector
from fpdf import FPDF
import razorpay

app = Flask(__name__)
app.secret_key = "hercomfort123"

# ---------------- DATABASE CONNECTION ---------------- #

conn = mysql.connector.connect(
    host="localhost",
    user="root",
    password="mysql",
    database="hercomfort"
)

cursor = conn.cursor(dictionary=True)

RAZORPAY_KEY_ID = "YOUR_TEST_KEY_ID"
RAZORPAY_KEY_SECRET = "YOUR_TEST_KEY_SECRET"

razorpay_client = razorpay.Client(
    auth=(RAZORPAY_KEY_ID, RAZORPAY_KEY_SECRET)
)
# ---------------- HOME ---------------- #

@app.route('/')
def home():

    # Products
    cursor.execute("""
        SELECT *
        FROM products
    """)

    products = cursor.fetchall()


    # Customer Reviews
    cursor.execute("""
        SELECT
            reviews.rating,
            reviews.review,
            reviews.review_date,
            users.name
        FROM reviews
        JOIN users
        ON reviews.user_id = users.id
        ORDER BY reviews.review_date DESC
        LIMIT 6
    """)

    reviews = cursor.fetchall()


    return render_template(
        "home.html",
        products=products,
        reviews=reviews
    )

# ---------------- REGISTER ---------------- #

@app.route('/register', methods=['GET', 'POST'])
def register():

    if request.method == 'POST':

        name = request.form['name']
        email = request.form['email']
        phone = request.form['phone']
        password = request.form['password']

        sql = """
        INSERT INTO users(name,email,phone,password)
        VALUES(%s,%s,%s,%s)
        """

        cursor.execute(sql, (name, email, phone, password))
        conn.commit()

        flash("Registration Successful")
        return redirect('/login')

    return render_template("register.html")


# ---------------- LOGIN ---------------- #

@app.route('/login', methods=['GET', 'POST'])
def login():

    if request.method == 'POST':

        email = request.form['email']
        password = request.form['password']

        sql = """
        SELECT * FROM users
        WHERE email=%s AND password=%s
        """

        cursor.execute(sql, (email, password))

        user = cursor.fetchone()

        if user:

            session['user_id'] = user['id']
            session['user_name'] = user['name']

            return redirect('/')

        else:

            flash("Invalid Email or Password")

    return render_template("login.html")


# ---------------- LOGOUT ---------------- #

@app.route('/logout')
def logout():

    session.clear()

    return redirect('/login')


# ---------------- PRODUCTS ---------------- #

@app.route('/products')
def products():

    cursor.execute("SELECT * FROM products")

    products = cursor.fetchall()

    return render_template("products.html", products=products)


@app.route('/search')
def search():

    search_query = request.args.get('search', '').strip()

    if not search_query:
        return redirect('/products')

    cursor.execute("""
        SELECT *
        FROM products
        WHERE product_name LIKE %s
        OR category LIKE %s
    """, (
        '%' + search_query + '%',
        '%' + search_query + '%'
    ))

    products = cursor.fetchall()

    return render_template(
        'products.html',
        products=products,
        search_query=search_query
    )


# ---------------- PRODUCT DETAILS ---------------- #

@app.route('/product/<int:id>')
def product_details(id):

    cursor.execute("SELECT * FROM products WHERE id=%s", (id,))

    product = cursor.fetchone()

    return render_template("product_details.html", product=product)

@app.route('/add_to_cart/<int:product_id>', methods=['POST'])
def add_to_cart(product_id):

    if 'user_id' not in session:
        flash("Please Login First")
        return redirect('/login')

    user_id = session['user_id']

    # 👇 He line ithe yeil
    selected_size = request.form['size']

    cursor.execute("""
    SELECT * FROM cart
    WHERE user_id=%s
    AND product_id=%s
    AND selected_size=%s
    """, (user_id, product_id, selected_size))

    item = cursor.fetchone()

    if item:

        cursor.execute("""
        UPDATE cart
        SET quantity = quantity + 1
        WHERE id=%s
        """, (item['id'],))

    else:

        cursor.execute("""
        INSERT INTO cart(user_id, product_id, quantity, selected_size)
        VALUES(%s, %s, %s, %s)
        """, (user_id, product_id, 1, selected_size))

    conn.commit()

    flash("Product Added To Cart")

    return redirect('/cart')

@app.route('/cart')
def cart():

    if 'user_id' not in session:
        return redirect('/login')

    user_id = session['user_id']

    sql = """
SELECT cart.id,
       cart.quantity,
       cart.selected_size,
       products.product_name,
       products.price,
       products.image
FROM cart
JOIN products
ON cart.product_id = products.id
WHERE cart.user_id = %s
"""
    

    cursor.execute(sql, (user_id,))
    cart_items = cursor.fetchall()

    total = 0

    for item in cart_items:
        total += item['price'] * item['quantity']

    return render_template(
        "cart.html",
        cart_items=cart_items,
        total=total
    )



@app.route('/remove_cart/<int:id>')
def remove_cart(id):

    cursor.execute("DELETE FROM cart WHERE id=%s",(id,))
    conn.commit()

    flash("Product Removed Successfully")

    return redirect('/cart')

@app.route('/increase_quantity/<int:id>')
def increase_quantity(id):

    cursor.execute("""
    UPDATE cart
    SET quantity = quantity + 1
    WHERE id=%s
    """, (id,))

    conn.commit()

    return redirect('/cart')

@app.route('/decrease_quantity/<int:id>')
def decrease_quantity(id):

    cursor.execute("SELECT quantity FROM cart WHERE id=%s", (id,))
    item = cursor.fetchone()

    if item['quantity'] > 1:

        cursor.execute("""
        UPDATE cart
        SET quantity = quantity - 1
        WHERE id=%s
        """, (id,))

    else:

        cursor.execute("""
        DELETE FROM cart
        WHERE id=%s
        """, (id,))

    conn.commit()

    return redirect('/cart')


@app.route('/order_success')
def order_success():

    if 'user_id' not in session:
        return redirect('/login')

    return render_template("order_success.html")

@app.route('/my_orders')
def my_orders():

    if 'user_id' not in session:
        return redirect('/login')

    user_id = session['user_id']

    cursor.execute("""
    SELECT *
    FROM orders
    WHERE user_id=%s
    ORDER BY order_date DESC
    """, (user_id,))

    orders = cursor.fetchall()

    return render_template(
        "my_orders.html",
        orders=orders
    )






@app.route('/admin_login', methods=['GET', 'POST'])
def admin_login():

    if request.method == "POST":

        username = request.form['username']
        password = request.form['password']

        cursor.execute("""
        SELECT * FROM admin
        WHERE username=%s AND password=%s
        """,(username,password))

        admin = cursor.fetchone()

        if admin:

            session['admin'] = admin['username']

            return redirect('/admin_dashboard')

        else:

            flash("Invalid Username or Password")

    return render_template("admin_login.html")


@app.route('/admin_dashboard')
def admin_dashboard():

    if 'admin' not in session:
        return redirect('/admin_login')

    cursor.execute("SELECT COUNT(*) AS total_products FROM products")
    total_products = cursor.fetchone()['total_products']

    cursor.execute("SELECT COUNT(*) AS total_users FROM users")
    total_users = cursor.fetchone()['total_users']

    cursor.execute("SELECT COUNT(*) AS total_orders FROM orders")
    total_orders = cursor.fetchone()['total_orders']

    return render_template(
        "admin_dashboard.html",
        total_products=total_products,
        total_users=total_users,
        total_orders=total_orders
    )


@app.route('/admin_products')
def admin_products():

    if 'admin' not in session:
        return redirect('/admin_login')

    cursor.execute("SELECT * FROM products")
    products = cursor.fetchall()

    return render_template(
        "admin_products.html",
        products=products
    )


@app.route('/admin_logout')
def admin_logout():

    session.pop('admin', None)

    return redirect('/admin_login')


@app.route('/add_product', methods=['GET', 'POST'])
def add_product():

    if 'admin' not in session:
        return redirect('/admin_login')

    if request.method == 'POST':

        product_name = request.form['product_name']
        category = request.form['category']
        price = request.form['price']
        sizes = request.form['sizes']
        colour = request.form['colour']
        description = request.form['description']
        image = request.form['image']   # Sadhya image filename manually

        cursor.execute("""
        INSERT INTO products
        (product_name, category, price, sizes, colour, description, image)
        VALUES(%s,%s,%s,%s,%s,%s,%s)
        """,
        (
            product_name,
            category,
            price,
            sizes,
            colour,
            description,
            image
        ))

        conn.commit()

        flash("Product Added Successfully")

        return redirect('/admin_products')

    return render_template("add_product.html")


@app.route('/edit_product/<int:id>', methods=['GET', 'POST'])
def edit_product(id):

    if 'admin' not in session:
        return redirect('/admin_login')

    if request.method == 'POST':

        product_name = request.form['product_name']
        category = request.form['category']
        price = request.form['price']
        sizes = request.form['sizes']
        colour = request.form['colour']
        description = request.form['description']
        image = request.form['image']

        cursor.execute("""
        UPDATE products
        SET
            product_name=%s,
            category=%s,
            price=%s,
            sizes=%s,
            colour=%s,
            description=%s,
            image=%s
        WHERE id=%s
        """,
        (
            product_name,
            category,
            price,
            sizes,
            colour,
            description,
            image,
            id
        ))

        conn.commit()

        flash("Product Updated Successfully")

        return redirect('/admin_products')

    cursor.execute("SELECT * FROM products WHERE id=%s",(id,))
    product = cursor.fetchone()

    return render_template("edit_product.html", product=product)


@app.route('/delete_product/<int:id>')
def delete_product(id):

    if 'admin' not in session:
        return redirect('/admin_login')

    cursor.execute("DELETE FROM products WHERE id=%s",(id,))
    conn.commit()

    flash("Product Deleted Successfully")

    return redirect('/admin_products')


@app.route('/admin_orders')
def admin_orders():

    if 'admin' not in session:
        return redirect('/admin_login')

    cursor.execute("""
        SELECT * FROM orders
        ORDER BY order_date DESC
    """)

    orders = cursor.fetchall()

    return render_template(
        'admin_orders.html',
        orders=orders
    )


@app.route('/update_order_status/<int:order_id>', methods=['POST'])
def update_order_status(order_id):

    if 'admin' not in session:
        return redirect('/admin_login')

    status = request.form['status']

    cursor.execute("""
        UPDATE orders
        SET order_status=%s
        WHERE id=%s
    """, (status, order_id))

    conn.commit()

    flash("Order status updated successfully!", "success")

    return redirect('/admin_orders')






@app.route('/view_order/<int:order_id>')
def view_order(order_id):

    if 'admin' not in session:
        return redirect('/admin_login')

    cursor.execute("""
        SELECT * FROM orders
        WHERE id=%s
    """, (order_id,))
    order = cursor.fetchone()

    cursor.execute("""
        SELECT * FROM order_items
        WHERE order_id=%s
    """, (order_id,))
    items = cursor.fetchall()

    return render_template(
        "view_order.html",
        order=order,
        items=items
    )

@app.route('/download_invoice/<int:order_id>')
def download_invoice(order_id):

    if 'user_id' not in session:
        return redirect('/login')

    cursor.execute("""
        SELECT *
        FROM orders
        WHERE id=%s AND user_id=%s
    """, (order_id, session['user_id']))

    order = cursor.fetchone()

    if not order:
        flash("Order not found!", "danger")
        return redirect('/my_orders')

    cursor.execute("""
        SELECT *
        FROM order_items
        WHERE order_id=%s
    """, (order_id,))

    items = cursor.fetchall()

    pdf = FPDF()
    pdf.add_page()

    pdf.set_font("Helvetica", "B", 20)
    pdf.cell(0, 10, "HER COMFORT", ln=True, align="C")

    pdf.ln(10)

    pdf.set_font("Helvetica", "B", 12)
    pdf.cell(0, 8, f"Order ID: #{order['id']}", ln=True)

    pdf.set_font("Helvetica", "", 11)

    pdf.cell(0, 7, f"Customer: {order['customer_name']}", ln=True)
    pdf.cell(0, 7, f"Phone: {order['phone']}", ln=True)
    pdf.cell(0, 7, f"Address: {order['address']}", ln=True)
    pdf.cell(0, 7, f"City: {order['city']}", ln=True)
    pdf.cell(0, 7, f"Pincode: {order['pincode']}", ln=True)
    pdf.cell(0, 7, f"Payment: {order['payment_method']}", ln=True)
    pdf.cell(0, 7, f"Status: {order['order_status']}", ln=True)

    pdf.ln(8)

    pdf.set_font("Helvetica", "B", 10)

    pdf.cell(65, 8, "Product", border=1)
    pdf.cell(25, 8, "Size", border=1)
    pdf.cell(20, 8, "Qty", border=1)
    pdf.cell(35, 8, "Price", border=1)
    pdf.cell(35, 8, "Total", border=1)

    pdf.ln()

    pdf.set_font("Helvetica", "", 10)

    for item in items:

        item_total = float(item['price']) * int(item['quantity'])

        pdf.cell(65, 8, str(item['product_name']), border=1)
        pdf.cell(25, 8, str(item['selected_size']), border=1)
        pdf.cell(20, 8, str(item['quantity']), border=1)
        pdf.cell(35, 8, f"Rs. {item['price']}", border=1)
        pdf.cell(35, 8, f"Rs. {item_total:.2f}", border=1)

        pdf.ln()

    pdf.ln(5)

    pdf.set_font("Helvetica", "B", 13)

    pdf.cell(
        0,
        10,
        f"Grand Total: Rs. {order['total_amount']}",
        ln=True,
        align="R"
    )

    filename = f"invoice_order_{order_id}.pdf"

    pdf.output(filename)

    return send_file(
        filename,
        as_attachment=True,
        download_name=filename
    )


@app.route('/payment_success', methods=['POST'])
def payment_success():

    if 'user_id' not in session:
        return {
            "success": False,
            "message": "Please login first."
        }, 401

    data = request.get_json()

    razorpay_payment_id = data.get(
        'razorpay_payment_id'
    )

    razorpay_order_id = data.get(
        'razorpay_order_id'
    )

    razorpay_signature = data.get(
        'razorpay_signature'
    )

    try:

        # Verify Razorpay signature
        razorpay_client.utility.verify_payment_signature({

            'razorpay_order_id':
                razorpay_order_id,

            'razorpay_payment_id':
                razorpay_payment_id,

            'razorpay_signature':
                razorpay_signature
        })

        user_id = session['user_id']

        pending_order = session.get(
            'pending_order'
        )

        if not pending_order:

            return {
                "success": False,
                "message": "Order information not found."
            }, 400

        # -------------------------
        # CREATE ORDER
        # -------------------------

        cursor.execute("""
            INSERT INTO orders
            (
                user_id,
                customer_name,
                phone,
                address,
                city,
                pincode,
                total_amount,
                payment_method,
                payment_status,
                order_status
            )
            VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
        """,
        (
            user_id,
            pending_order['customer_name'],
            pending_order['phone'],
            pending_order['address'],
            pending_order['city'],
            pending_order['pincode'],
            pending_order['total'],
            "Online",
            "Paid",
            "Pending"
        ))

        conn.commit()

        order_id = cursor.lastrowid

        # -------------------------
        # ORDER ITEMS
        # -------------------------

        for item in pending_order['cart_items']:

            cursor.execute("""
                INSERT INTO order_items
                (
                    order_id,
                    product_id,
                    product_name,
                    selected_size,
                    quantity,
                    price
                )
                VALUES(%s,%s,%s,%s,%s,%s)
            """,
            (
                order_id,
                item['product_id'],
                item['product_name'],
                item['selected_size'],
                item['quantity'],
                item['price']
            ))

        # -------------------------
        # PAYMENT RECORD
        # -------------------------

        cursor.execute("""
            INSERT INTO payments
            (
                order_id,
                payment_mode,
                payment_status,
                transaction_id,
                razorpay_order_id,
                razorpay_payment_id,
                razorpay_signature
            )
            VALUES(%s,%s,%s,%s,%s,%s,%s)
        """,
        (
            order_id,
            "Online",
            "Paid",
            razorpay_payment_id,
            razorpay_order_id,
            razorpay_payment_id,
            razorpay_signature
        ))

        # -------------------------
        # CLEAR CART
        # -------------------------

        cursor.execute(
            "DELETE FROM cart WHERE user_id=%s",
            (user_id,)
        )

        conn.commit()

        # Remove temporary order
        session.pop(
            'pending_order',
            None
        )

        return {
            "success": True,
            "order_id": order_id
        }

    except Exception as e:

        conn.rollback()

        print("PAYMENT ERROR:", e)

        return {
            "success": False,
            "message": "Payment verification failed."
        }, 400



@app.route('/checkout', methods=['GET', 'POST'])
def checkout():

    if 'user_id' not in session:
        return redirect('/login')

    user_id = session['user_id']

    # Get cart items
    cursor.execute("""
        SELECT
            cart.product_id,
            cart.quantity,
            cart.selected_size,
            products.product_name,
            products.price
        FROM cart
        JOIN products
        ON cart.product_id = products.id
        WHERE cart.user_id=%s
    """, (user_id,))

    cart_items = cursor.fetchall()

    if not cart_items:
        flash("Your cart is empty!", "warning")
        return redirect('/cart')

    # Calculate total
    total = 0

    for item in cart_items:
        total += float(item['price']) * int(item['quantity'])

    # POST
    if request.method == "POST":

        customer_name = request.form['customer_name']
        phone = request.form['phone']
        address = request.form['address']
        city = request.form['city']
        pincode = request.form['pincode']
        payment_method = request.form['payment_method']

        # =========================
        # COD
        # =========================

        if payment_method == "COD":

            cursor.execute("""
                INSERT INTO orders
                (
                    user_id,
                    customer_name,
                    phone,
                    address,
                    city,
                    pincode,
                    total_amount,
                    payment_method,
                    payment_status,
                    order_status
                )
                VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
            """, (
                user_id,
                customer_name,
                phone,
                address,
                city,
                pincode,
                total,
                "COD",
                "Pending",
                "Pending"
            ))

            conn.commit()

            order_id = cursor.lastrowid

            # Save order items
            for item in cart_items:

                cursor.execute("""
                    INSERT INTO order_items
                    (
                        order_id,
                        product_id,
                        product_name,
                        selected_size,
                        quantity,
                        price
                    )
                    VALUES (%s,%s,%s,%s,%s,%s)
                """, (
                    order_id,
                    item['product_id'],
                    item['product_name'],
                    item['selected_size'],
                    item['quantity'],
                    item['price']
                ))

            # Save payment
            cursor.execute("""
                INSERT INTO payments
                (
                    order_id,
                    payment_mode,
                    payment_status,
                    transaction_id
                )
                VALUES (%s,%s,%s,%s)
            """, (
                order_id,
                "COD",
                "Pending",
                None
            ))

            # Clear cart
            cursor.execute(
                "DELETE FROM cart WHERE user_id=%s",
                (user_id,)
            )

            conn.commit()

            flash("Order Placed Successfully!", "success")

            return redirect('/order_success')

        # =========================
        # ONLINE PAYMENT
        # =========================

        elif payment_method == "Online":

            amount_paise = int(round(total * 100))

            razorpay_order = razorpay_client.order.create({
                "amount": amount_paise,
                "currency": "INR",
                "payment_capture": 1
            })

            # Store order information temporarily
            session['pending_order'] = {
                "customer_name": customer_name,
                "phone": phone,
                "address": address,
                "city": city,
                "pincode": pincode,
                "total": total,
                "cart_items": cart_items
            }

            return render_template(
                "razorpay_payment.html",
                razorpay_order_id=razorpay_order['id'],
                razorpay_key_id=RAZORPAY_KEY_ID,
                amount=amount_paise,
                customer_name=customer_name,
                phone=phone
            )

    return render_template(
        "checkout.html",
        total=total
    )


@app.route('/write_review/<int:order_id>/<int:product_id>', methods=['GET', 'POST'])
def write_review(order_id, product_id):

    if 'user_id' not in session:
        return redirect('/login')

    user_id = session['user_id']

    # Check product
    cursor.execute("""
        SELECT *
        FROM products
        WHERE id=%s
    """, (product_id,))

    product = cursor.fetchone()

    if not product:
        flash("Product not found", "danger")
        return redirect('/my_orders')


    # Check whether customer actually ordered this product
    cursor.execute("""
        SELECT oi.id
        FROM order_items oi
        JOIN orders o
        ON oi.order_id = o.id
        WHERE oi.order_id=%s
        AND oi.product_id=%s
        AND o.user_id=%s
        AND o.order_status='Delivered'
    """, (order_id, product_id, user_id))

    purchased = cursor.fetchone()

    if not purchased:
        flash("You can review only products from your delivered orders.", "danger")
        return redirect('/my_orders')


    # Check if already reviewed
    cursor.execute("""
        SELECT id
        FROM reviews
        WHERE user_id=%s
        AND order_id=%s
        AND product_id=%s
    """, (user_id, order_id, product_id))

    existing_review = cursor.fetchone()

    if existing_review:
        flash("You have already reviewed this product.", "warning")
        return redirect('/my_orders')


    # Submit review
    if request.method == 'POST':

        rating = request.form['rating']
        review = request.form['review'].strip()

        if not review:
            flash("Please write a review.", "danger")
            return redirect(
                f'/write_review/{order_id}/{product_id}'
            )

        cursor.execute("""
            INSERT INTO reviews
            (
                user_id,
                order_id,
                product_id,
                rating,
                review
            )
            VALUES (%s,%s,%s,%s,%s)
        """,
        (
            user_id,
            order_id,
            product_id,
            rating,
            review
        ))

        conn.commit()

        flash("Thank you! Your review has been submitted.", "success")

        return redirect('/my_orders')


    return render_template(
        'write_review.html',
        product=product,
        order_id=order_id
    )


@app.route('/order_details/<int:order_id>')
def order_details(order_id):

    if 'user_id' not in session:
        return redirect('/login')

    user_id = session['user_id']

    # Get order
    cursor.execute("""
        SELECT *
        FROM orders
        WHERE id=%s AND user_id=%s
    """, (order_id, user_id))

    order = cursor.fetchone()

    if not order:
        flash("Order not found", "danger")
        return redirect('/my_orders')

    # Get products of this order
    cursor.execute("""
        SELECT *
        FROM order_items
        WHERE order_id=%s
    """, (order_id,))

    items = cursor.fetchall()

    return render_template(
        'order_details.html',
        order=order,
        items=items
    )


# ---------------- RUN ---------------- #

if __name__ == '__main__':
    app.run(debug=True)