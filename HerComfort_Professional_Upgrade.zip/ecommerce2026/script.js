// ==========================
// FLASH SALE COUNTDOWN
// ==========================


let hours = 5;
let minutes = 59;
let seconds = 59;


function updateTimer(){


let timer = document.getElementById("countdown");


if(timer){


seconds--;


if(seconds < 0){

    seconds = 59;
    minutes--;

}


if(minutes < 0){

    minutes = 59;
    hours--;

}



if(hours < 0){

    hours = 5;
    minutes = 59;
    seconds = 59;

}



timer.innerHTML =
String(hours).padStart(2,'0')
+ " : " +

String(minutes).padStart(2,'0')
+ " : " +

String(seconds).padStart(2,'0');

}



}


setInterval(updateTimer,1000);





// ==========================
// SCROLL TO TOP
// ==========================


let topButton = document.getElementById("topBtn");


window.onscroll=function(){


if(document.body.scrollTop > 300 ||
document.documentElement.scrollTop > 300)
{

topButton.style.display="block";

}

else{

topButton.style.display="none";

}


};





function topFunction(){

window.scrollTo({

top:0,

behavior:"smooth"

});

}





// ==========================
// NAVBAR EFFECT
// ==========================


window.addEventListener("scroll",function(){


let navbar=document.querySelector(".custom-nav");


if(window.scrollY > 50){


navbar.style.background="white";

navbar.style.boxShadow=
"0 5px 20px rgba(0,0,0,.15)";


}

else{


navbar.style.background=
"rgba(255,255,255,0.85)";


navbar.style.boxShadow="none";


}


});





// ==========================
// IMAGE LAZY EFFECT
// ==========================


const images=document.querySelectorAll("img");


images.forEach(img=>{


img.addEventListener("load",()=>{

img.style.opacity="1";

});


});